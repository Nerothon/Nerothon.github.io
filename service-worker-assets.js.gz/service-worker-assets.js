self.assetsManifest = {
  "version": "musdxVn5",
  "assets": [
    {
      "hash": "sha256-Cgdy8Dsy/IR9lZ35uGWZmPZOza2l8CjvZP75EYpIejg=",
      "url": ".gitattributes"
    },
    {
      "hash": "sha256-Rk+XDzdxRb7anRZDXyIQjufGs84+rJm3UdJ39aLerW4=",
      "url": ".gitignore"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-cU4gLbM0coS9kFukpjbAt1NPD4Cx9hyAeaiK0FPscIM=",
      "url": "Data/JSON/Pet.json"
    },
    {
      "hash": "sha256-ITU/qvoij4AT4ulGGE2giy/6MNeAN2NKI3jFQgEapCA=",
      "url": "Wizard101.Blazor.WebAssembly.styles.css"
    },
    {
      "hash": "sha256-Z094C6tvTOKvix221ZuSPsaaNvGOp0XKqThmB4vfuOA=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lib.module.js"
    },
    {
      "hash": "sha256-PYJ3IBSIJu8xy0XOmNAcukivZln/Q+yOSviCaIMTUCg=",
      "url": "_framework/Dapper.hj0ug1b3le.wasm"
    },
    {
      "hash": "sha256-HK/bv9+Y0YTsrvQOSHsJnQXj3Qr8ma+OnPlZhlcWMrA=",
      "url": "_framework/DynamicData.8r53t9xgm4.wasm"
    },
    {
      "hash": "sha256-tPIOFMZjBzAkwM4VRfWPT3s7Y9lOnm+oO0JMCSy9p4A=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.g92tul72wl.wasm"
    },
    {
      "hash": "sha256-pu76rHZnWXnD8OJbsfHeWNtvNYwvUMrsao8y79n+GXY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.mhi741p0i5.wasm"
    },
    {
      "hash": "sha256-L5HTWpzbSW8fQBcAPiSte6cKr2DrCYFlWl8yw8JpCRw=",
      "url": "_framework/Microsoft.AspNetCore.Components.r9d0adnpye.wasm"
    },
    {
      "hash": "sha256-U+kQxfHDDP2QB94GRi+tVF5W1YqYQ/gu3DoqSJJAQgQ=",
      "url": "_framework/Microsoft.CSharp.d026rzmgbe.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-xJGsdCHz8ZnqW4DMzEAjFDJG+hPSdDKvwcYEdt/HJTE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.greu41qkcj.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-Pmq0WBMgjHXH2dCCDxV12WW8lvXrO4ctTn4jmRDjM4E=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6zla843dui.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-iOXJ6xMILdIdSWDD2fNHtnrXI0YtuWx4chp/bwgCVgc=",
      "url": "_framework/Microsoft.Extensions.Primitives.8omryeirak.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-HZfJdOt7lLkyhRFKw4lRlMV/K2gDW5ioaRsPTXJHZys=",
      "url": "_framework/ReactiveUI.Fody.Helpers.tclkecf6xz.wasm"
    },
    {
      "hash": "sha256-FD15kVoh5mtIdf6700NSj2jWVzuCg/RotRSU3wLuGIg=",
      "url": "_framework/ReactiveUI.c6b2s3hs7l.wasm"
    },
    {
      "hash": "sha256-VYXXOoyoCWNTMQcXbxgV4sTcCIWNDAvShTrTyRXegAw=",
      "url": "_framework/Splat.xt6vhwicf8.wasm"
    },
    {
      "hash": "sha256-nmhUPBjB8ZbEN0U5j2acgnW4fkbSYlov7U3e30Lsp8A=",
      "url": "_framework/System.6bp5k9v1ih.wasm"
    },
    {
      "hash": "sha256-yM6tthLPysafygagTyZEA5/KoDLMABCcsWZ8ofnj8GQ=",
      "url": "_framework/System.Collections.Concurrent.4lwtfqh74w.wasm"
    },
    {
      "hash": "sha256-l4XK0rR/L78FfNdGce1vcbD5+zauHcLnVajffKICdgc=",
      "url": "_framework/System.Collections.Immutable.jxadlu6tsx.wasm"
    },
    {
      "hash": "sha256-SJYUcmdiJQ2+uUqHKxHQ/P74RFwIpHTfj+QiovwpP60=",
      "url": "_framework/System.Collections.NonGeneric.w21ldx28om.wasm"
    },
    {
      "hash": "sha256-PbaoBylerizC1TvoSwekylSfMST9LShCdbB4XZR4W7k=",
      "url": "_framework/System.Collections.Specialized.z0iakjxs5k.wasm"
    },
    {
      "hash": "sha256-RSn2AVBigKDxojFSGuIhbzicxDWatOf1C1LjJj3To7M=",
      "url": "_framework/System.Collections.bolcyb7ccl.wasm"
    },
    {
      "hash": "sha256-A/SwZxlXy81HluZ0UqZ/FXnkeLpLlAQ7Ls6SsOMVYUk=",
      "url": "_framework/System.ComponentModel.Annotations.7fizku2rpk.wasm"
    },
    {
      "hash": "sha256-K7bj/z+2t9JflDN7eDg8M/AYY/RjrVg2WKB00tWibk0=",
      "url": "_framework/System.ComponentModel.Primitives.f3ro3l8hjy.wasm"
    },
    {
      "hash": "sha256-IPvVEIvjqWfxNNKiR/EEbZgWwwW/zE+UpiGO9Zq5HFc=",
      "url": "_framework/System.ComponentModel.TypeConverter.k3eqfr4h9s.wasm"
    },
    {
      "hash": "sha256-FxQd6muAN/l79eiBv2/IrkShDUaCGQYx1jdTKBPdlgw=",
      "url": "_framework/System.ComponentModel.ngcc612btm.wasm"
    },
    {
      "hash": "sha256-AXh0c9elGK4mTMJidXe6ltbD1gq9RIQOGGn653KM2WY=",
      "url": "_framework/System.Console.h85ihzbzrz.wasm"
    },
    {
      "hash": "sha256-m0bLD+XCwslcTpAgDZ3sd8cgU3tiGMkUrd1BCpXkg3o=",
      "url": "_framework/System.Data.Common.rkjyznr9i9.wasm"
    },
    {
      "hash": "sha256-+lNpk+0KqSWqUjMRG2j5VY98SjWYCd06gZpKX993+2A=",
      "url": "_framework/System.Data.SQLite.qv9cb1it5a.wasm"
    },
    {
      "hash": "sha256-DpXnRV0e7N3isu3DTTwiq1dfwcbaXACcMfM8QWO5L/g=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ay6j18k77x.wasm"
    },
    {
      "hash": "sha256-WFbgste+wtGbGCOT+7BtEU0QGvsOm9AY0g5OQ+DmUww=",
      "url": "_framework/System.Diagnostics.Process.gumokbkpz9.wasm"
    },
    {
      "hash": "sha256-bl1R3isc+5jPrM2gz7S3/91BDFwg4vg1VLGQlXXe5JQ=",
      "url": "_framework/System.Diagnostics.TraceSource.e9suwyto82.wasm"
    },
    {
      "hash": "sha256-DHg9bph31QjZoMvj6a0ojbRvO0bc+KO25T+fHvMgWPs=",
      "url": "_framework/System.Drawing.Primitives.o33pwrw9f3.wasm"
    },
    {
      "hash": "sha256-7OYyS/EvxxJePK8hvB0aD96TeLlyptw5TWV6IDYwhc8=",
      "url": "_framework/System.Drawing.w36gg13qvp.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-n7AbJPccP+BuYq/eiyEw/iImS6Ifiqntq5KJefgINzg=",
      "url": "_framework/System.Linq.Expressions.nmjx3f58uf.wasm"
    },
    {
      "hash": "sha256-v3/bdAtj/BUfKFDaq8px7cBIvvlNR8L9nBHf2vEUPsQ=",
      "url": "_framework/System.Linq.Parallel.bp77t0yo1e.wasm"
    },
    {
      "hash": "sha256-woTXJTZ8AB210JQxLsJYUJbloPB4n5AHZe4moLG1SkQ=",
      "url": "_framework/System.Linq.m2mustwi2n.wasm"
    },
    {
      "hash": "sha256-I8VWyuQW6vuwxP1LYANSKzKmP5n224wuKHyNCrx5cn8=",
      "url": "_framework/System.Memory.d8bwii2l0b.wasm"
    },
    {
      "hash": "sha256-9pmE0086MdwRaJMg3JZgg8m31zPg6J6MRmn39gNkoLs=",
      "url": "_framework/System.Net.Http.Json.a7bd8euxna.wasm"
    },
    {
      "hash": "sha256-F1wmvnxsh6AgMpkB5QMPdbVrrjumzxwMvzCJH2AEEHg=",
      "url": "_framework/System.Net.Http.b75jfrkfi9.wasm"
    },
    {
      "hash": "sha256-rGsc0Rj+aWTuEy/xrVLyqYbtC/7f6oRKD/zu7TpfU0Q=",
      "url": "_framework/System.Net.Primitives.01n7ob4nyz.wasm"
    },
    {
      "hash": "sha256-O4tP6+V/amKWCXyjeSZfgEhIFNRfwR0MwgVIvl9bOVQ=",
      "url": "_framework/System.ObjectModel.xd9tc1r73o.wasm"
    },
    {
      "hash": "sha256-SX9UCc1irpEs/04ftX/v4awpmviXNLLu6pkOp0RlSqo=",
      "url": "_framework/System.Private.CoreLib.tnf04ftx7b.wasm"
    },
    {
      "hash": "sha256-2x4JXCWIYrO1u37pY/JR3y+SF0cLjCWk0y0oonPaHdA=",
      "url": "_framework/System.Private.Uri.pjumlmd65t.wasm"
    },
    {
      "hash": "sha256-/kEogGHAuvmP8s1anlxqRrTM1nXGOh9F4DyK2BvoXcQ=",
      "url": "_framework/System.Private.Xml.Linq.67g8agz868.wasm"
    },
    {
      "hash": "sha256-g6a+Fd1RfPYzQj8SmC8wLZc2q9gG9txH14f3scyxoHo=",
      "url": "_framework/System.Private.Xml.vhgwbcnmyq.wasm"
    },
    {
      "hash": "sha256-4HwE8h6y12X5aTHRxgDAa4EatyRzPz8fAHgbzBW2Q/c=",
      "url": "_framework/System.Reactive.8yt6msyf3k.wasm"
    },
    {
      "hash": "sha256-gP+HYHzPCqozAAabaDbzFh+7DJLPJ1sdH9w/d0MxzbU=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.oyya4rylr5.wasm"
    },
    {
      "hash": "sha256-5XUvHhr+USgxFvmU7VVIWmFS7fwgsd0sSnIae9pKDAM=",
      "url": "_framework/System.Reflection.Emit.Lightweight.l4ojtalmyq.wasm"
    },
    {
      "hash": "sha256-YQDKI2k1d6ATDOvjsrM7U4AN4tjTJw6nlAo/0GnC1rQ=",
      "url": "_framework/System.Reflection.Primitives.pi8p9sv67y.wasm"
    },
    {
      "hash": "sha256-oC6wy6Nz0zzoLccWMXxRMyeLX3GAKp3N3C7QgJma7WU=",
      "url": "_framework/System.Runtime.0cnh5v836k.wasm"
    },
    {
      "hash": "sha256-K5wa4QwWB8A0OrHM4yWK86Nl6ItEv9c3ctAASLMYLKo=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.3uvku0ibnu.wasm"
    },
    {
      "hash": "sha256-DuXpGIFn9if4yW08yJLplmZKBw21eFlNoWfUhs11WpY=",
      "url": "_framework/System.Runtime.InteropServices.qyh4f6a8ii.wasm"
    },
    {
      "hash": "sha256-RoLL7Mbp9cSua+dPxyNUbHJ4Gn7/HrMIxDy+aDUCI6A=",
      "url": "_framework/System.Runtime.Numerics.evpbazfm85.wasm"
    },
    {
      "hash": "sha256-x7iwOtKj4GzKIHbFzt/zwxQK+28dIrUDa6WDe+MjvCQ=",
      "url": "_framework/System.Runtime.Serialization.Formatters.pwm54clf38.wasm"
    },
    {
      "hash": "sha256-mxj6Y2+SUp6FDvUlMn6MJqJW4e503ymYYKvbway564g=",
      "url": "_framework/System.Runtime.Serialization.Primitives.19m77ppyem.wasm"
    },
    {
      "hash": "sha256-cHYzgafOkkmgRATl/ujePf3L4pKL2+yIA0PLXttA184=",
      "url": "_framework/System.Security.Cryptography.omu65xidsd.wasm"
    },
    {
      "hash": "sha256-FsNtnmSmX8069WLOrvOhtCUt2wU0YFzbOL9okLMg2Gw=",
      "url": "_framework/System.Text.Encoding.Extensions.yx11f5emv7.wasm"
    },
    {
      "hash": "sha256-3w9jcvf72CdfcHber8bV+MG+QG9Eov1eSxYBJ65smAE=",
      "url": "_framework/System.Text.Encodings.Web.3fsw0egfwc.wasm"
    },
    {
      "hash": "sha256-2TGDV7kbwJ+HoIkx/mFpX7GhDDXxRr+5/bSzAVVrC0c=",
      "url": "_framework/System.Text.Json.vqeq1kpo9p.wasm"
    },
    {
      "hash": "sha256-3iYX4kF2wCnSNHSrdW0F1RyIdIh6E4M0ppuH3flZdts=",
      "url": "_framework/System.Text.RegularExpressions.iwps7kru22.wasm"
    },
    {
      "hash": "sha256-6xaHygbX7F83rWAd1B1woTB85WhYNZaLmeqPotktRUc=",
      "url": "_framework/System.Threading.vjm3a2jb8z.wasm"
    },
    {
      "hash": "sha256-kI6MmDCfbKzf5VPlg6sNqm7e6sZ7Ppny5Hv9Dx3C+y4=",
      "url": "_framework/System.Transactions.Local.clrjblk7jm.wasm"
    },
    {
      "hash": "sha256-50dVChh2QJYCLLia2vmYR8/Cyxw2D7Y5dFwnnzVUiZ0=",
      "url": "_framework/System.Xml.Linq.bbx5kr3gw0.wasm"
    },
    {
      "hash": "sha256-ZxI4q0f4gYcuEEdE53XEjuInY0fZhEwGLFz6tDLfkWI=",
      "url": "_framework/System.Xml.ReaderWriter.n8jgpxrj3l.wasm"
    },
    {
      "hash": "sha256-5uzroEB10mAZCZ0VTgdXoiF0kOCNX27xMjgMkPlWa/w=",
      "url": "_framework/System.Xml.XDocument.q32h0u5hry.wasm"
    },
    {
      "hash": "sha256-MmxY1SqLxBfzOuirfXYwyUmBz9VUS5q9i8VQA01mQE8=",
      "url": "_framework/Wizard101.Blazor.WebAssembly.6mro2oprym.wasm"
    },
    {
      "hash": "sha256-2P4DxZcQW3AfJOyUT+51aa0iD627nz4DoxG3hrmbFCQ=",
      "url": "_framework/Wizard101.Library.oo2xvpbt5g.wasm"
    },
    {
      "hash": "sha256-yx+/kuUd2Fgrg6HicgRIPRUDyto5ovpPrGY6eSninRM=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-A0NeDQJvhivk1n3TEkNnliFk1iD0ALIIKtCKc7zOXG0=",
      "url": "_framework/dotnet.native.hz4fea4id3.wasm"
    },
    {
      "hash": "sha256-6HnB3Cvn1+9OkcofQyEnwKhUMICT+lO+8SQGe3YptD4=",
      "url": "_framework/dotnet.native.o444s4q30d.js"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vYz+v5yzxCLdKtDX6751b0yRTu34OJ7cbp7rfIkfc3o=",
      "url": "_framework/netstandard.73li4hlike.wasm"
    },
    {
      "hash": "sha256-pp1/7uMmkKou/NKkl6A72W79PEJuL8VkBRMQStNqQ4U=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-HrDVZitZMAE9cgWh0iIiCzrhEEA/lEIFCxMZtxIq2ps=",
      "url": "fonts/Wizard Fancy.ttf"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-qR/R3E8l7XtUfP3/iyDTyX98sxyGmj4huO9kQkPZF68=",
      "url": "index.html"
    },
    {
      "hash": "sha256-/WYZQLmsmX2mEupA8wFOkt8vSqD5O9f7oUwvcBeZyU4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-73JZ1gHKuu5PTiginsJy+nbi40Bb8KfF7utVbi2O/rA=",
      "url": "sitemap.xml"
    },
    {
      "hash": "sha256-OdEkj53XDzoYb0un5CpQz96SKM3vSTEmkoWW/s1THOo=",
      "url": "spellbook.png"
    }
  ]
};
