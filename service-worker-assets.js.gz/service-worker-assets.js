self.assetsManifest = {
  "version": "jlq9teAl",
  "assets": [
    {
      "hash": "sha256-Cgdy8Dsy/IR9lZ35uGWZmPZOza2l8CjvZP75EYpIejg=",
      "url": ".gitattributes"
    },
    {
      "hash": "sha256-Rk+XDzdxRb7anRZDXyIQjufGs84+rJm3UdJ39aLerW4=",
      "url": ".gitignore"
    },
    {
      "hash": "sha256-8ZRc1sGeVrPBx4lD717BgRaQekyh78QKV9SKsdt638U=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-cU4gLbM0coS9kFukpjbAt1NPD4Cx9hyAeaiK0FPscIM=",
      "url": "Data/JSON/Pet.json"
    },
    {
      "hash": "sha256-I8kcjcGNIM6u/tnEMyMG2dWGeXFfzsucsu64X7XGYxs=",
      "url": "Wizard101.Blazor.WebAssembly.styles.css"
    },
    {
      "hash": "sha256-Z094C6tvTOKvix221ZuSPsaaNvGOp0XKqThmB4vfuOA=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lib.module.js"
    },
    {
      "hash": "sha256-PYJ3IBSIJu8xy0XOmNAcukivZln/Q+yOSviCaIMTUCg=",
      "url": "_framework/Dapper.hj0ug1b3le.wasm"
    },
    {
      "hash": "sha256-HK/bv9+Y0YTsrvQOSHsJnQXj3Qr8ma+OnPlZhlcWMrA=",
      "url": "_framework/DynamicData.8r53t9xgm4.wasm"
    },
    {
      "hash": "sha256-WscRSXYnCnRsnZYCCSlQvV93hLw+HZgQETNPzp9JVPk=",
      "url": "_framework/Microsoft.AspNetCore.Components.2i1bfrbe52.wasm"
    },
    {
      "hash": "sha256-36hHDTibskZWJe1Hq2n48ALccRhTYjhdgYIkEBdFYlo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.3fgbtp8v0v.wasm"
    },
    {
      "hash": "sha256-t3VSeRLSoX9ADJF7SC5389g96IcrRzAAjZ6zuSfGJmA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.rnazpfwotd.wasm"
    },
    {
      "hash": "sha256-aSLzjUG9SRyTc6qmnRkw0fCu/QiARR+wEaE+AiYbioU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.z581my2xiy.wasm"
    },
    {
      "hash": "sha256-VYpmh/++8od0fmV5tHGxBiKtWRdnssiL2UXqK+EsEc8=",
      "url": "_framework/Microsoft.CSharp.l4nhbw5tnj.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-wyf8Vo6UgYf0nBwXNCaCuIFe0U/I9p7vR4d7VpKg8fQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.t8c9edx0n1.wasm"
    },
    {
      "hash": "sha256-MFB5EtcD1XqYwTheZ3IWOsPfIWutpvK0MzF+GSwrl8I=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.sxddgq7smo.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-aghFR5ix2EFcXsXxIjilRm2GirVLMF7NAkzXIR0Y9JY=",
      "url": "_framework/Microsoft.Extensions.Options.er9kaksr7l.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-LuYfR4a5fwfclUwXPnTjZGpINIjF23AhCZmTFWP2xbQ=",
      "url": "_framework/Microsoft.JSInterop.iknej2zdh8.wasm"
    },
    {
      "hash": "sha256-GlXMWKvDs45M2pACoR3Y4Qh8mcrOZGljqmvJY+6JZ5s=",
      "url": "_framework/Newtonsoft.Json.qkbufwhni2.wasm"
    },
    {
      "hash": "sha256-HZfJdOt7lLkyhRFKw4lRlMV/K2gDW5ioaRsPTXJHZys=",
      "url": "_framework/ReactiveUI.Fody.Helpers.tclkecf6xz.wasm"
    },
    {
      "hash": "sha256-FD15kVoh5mtIdf6700NSj2jWVzuCg/RotRSU3wLuGIg=",
      "url": "_framework/ReactiveUI.c6b2s3hs7l.wasm"
    },
    {
      "hash": "sha256-VYXXOoyoCWNTMQcXbxgV4sTcCIWNDAvShTrTyRXegAw=",
      "url": "_framework/Splat.xt6vhwicf8.wasm"
    },
    {
      "hash": "sha256-DzhrCSWFocf5MsYClPqSbb/oi1iMghifb2JBpBUD3Fg=",
      "url": "_framework/System.Collections.Concurrent.dtlyx5buga.wasm"
    },
    {
      "hash": "sha256-1RHexqLNHbjGiFhVGnr0JdwEMvzUiLUY/ycIrm1O1ZA=",
      "url": "_framework/System.Collections.Immutable.7pu3oqzllx.wasm"
    },
    {
      "hash": "sha256-RnFDgR1ivQNPhqotX0L13hu3d8tHb6zwUmaZvs68J9A=",
      "url": "_framework/System.Collections.NonGeneric.uml39a9tnh.wasm"
    },
    {
      "hash": "sha256-kwYlsJTnS2IdLa6waLKklrvEKrVYHnZ3/rewZikyv4w=",
      "url": "_framework/System.Collections.Specialized.bm70clq5zk.wasm"
    },
    {
      "hash": "sha256-Xn6jlSruGqIyljkGGQM5ZxhskTSPGw3iuG11E73W4rw=",
      "url": "_framework/System.Collections.u47ddzcncc.wasm"
    },
    {
      "hash": "sha256-REGsi8Ht+nS4miONmjRL5OcyOCOgpCE2JMZU1mSQvdE=",
      "url": "_framework/System.ComponentModel.Annotations.8tufda6qoj.wasm"
    },
    {
      "hash": "sha256-cpKYoeN+ogangy1yKdRNSSJOvBdkDzBJHAM7zbp1+uU=",
      "url": "_framework/System.ComponentModel.Primitives.izpcvc7z4x.wasm"
    },
    {
      "hash": "sha256-+0oseCyvuS7aLZSjvZukFdka/rQJ1JWyJOdOUq3UeEY=",
      "url": "_framework/System.ComponentModel.TypeConverter.5wkpjfjf3x.wasm"
    },
    {
      "hash": "sha256-4OeCSQDmifJ2n9IkYtCOhmXb5hb+BPnwQgu9fkz8O/E=",
      "url": "_framework/System.ComponentModel.kji4l3l9h2.wasm"
    },
    {
      "hash": "sha256-BRh9rr4UTrlXRT+5u/XGjd4hFcrKBjqfngKiHMBTqqU=",
      "url": "_framework/System.Console.lsslnr5uuz.wasm"
    },
    {
      "hash": "sha256-28sdlCO1aG0OlZ0+xN9JXXGQ4jLAUVwrldONhTm9Tbw=",
      "url": "_framework/System.Data.Common.7l6mh0pnyq.wasm"
    },
    {
      "hash": "sha256-+lNpk+0KqSWqUjMRG2j5VY98SjWYCd06gZpKX993+2A=",
      "url": "_framework/System.Data.SQLite.qv9cb1it5a.wasm"
    },
    {
      "hash": "sha256-mPXh53MMYsZTp+L7rAZoMo6EKUtuxL5dxuVfdNwpmMs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.crwz9broo6.wasm"
    },
    {
      "hash": "sha256-AAFs1iyrPtCi7lnEOHyBWU0NjSW9sCXkGFUnS6xeRJA=",
      "url": "_framework/System.Diagnostics.Process.0w88s51pcf.wasm"
    },
    {
      "hash": "sha256-/SgNY1THQyA//cSRwdj0RT4q7uIQ7ECxF1cRb/YKQzQ=",
      "url": "_framework/System.Diagnostics.TraceSource.pp2xliekwf.wasm"
    },
    {
      "hash": "sha256-zcqU4bLpKQ2pq4uHcy/xso1tunN7P/fStG6uOZdOlqY=",
      "url": "_framework/System.Drawing.30nntpi0qg.wasm"
    },
    {
      "hash": "sha256-0lNfxvFw0wlqNjAz5IKZnRbXTUmoetlkqq6sa8kDwRA=",
      "url": "_framework/System.Drawing.Primitives.2gldui05my.wasm"
    },
    {
      "hash": "sha256-A/zbBw0DrouhwRThvr8F1IcKa5ApGW5BE01HoHB7igA=",
      "url": "_framework/System.IO.Pipelines.twix2pm6u4.wasm"
    },
    {
      "hash": "sha256-8yGAZ2/EMmSD2WQ/mWeOnxrlD7L4FOmnug9iEDMop3g=",
      "url": "_framework/System.Linq.Expressions.px1xe28v2y.wasm"
    },
    {
      "hash": "sha256-J3yJBrlNl8VRi4TvIENgGGBtI2+RWnyLJuCjJcFi80g=",
      "url": "_framework/System.Linq.Parallel.jl6nb40ups.wasm"
    },
    {
      "hash": "sha256-y1p3RHtW/K0nQUVRzyiwGSEeurNcBbm9dIDiDJLuErM=",
      "url": "_framework/System.Linq.vfp0yq5ec7.wasm"
    },
    {
      "hash": "sha256-ELv1WOW2IxWs5ZJi58aQy3wvEg4rsf9HjqSH90jTz30=",
      "url": "_framework/System.Memory.ww9v9ea3r3.wasm"
    },
    {
      "hash": "sha256-eGcJF7s1zPxULh9xtxda8PqhurTMRTcbCCAxILz6aOs=",
      "url": "_framework/System.Net.Http.0mqbgn8bd0.wasm"
    },
    {
      "hash": "sha256-+UYnoln0qDJD3pk1bV6a29MDMIxDLwKkciwAcuU0zKY=",
      "url": "_framework/System.Net.Http.Json.d77yizflkj.wasm"
    },
    {
      "hash": "sha256-Veph07He3TSSf+3cu5ruZk1lvh6cN+E2+LMd/PcVgG0=",
      "url": "_framework/System.Net.Primitives.bg60hpoftx.wasm"
    },
    {
      "hash": "sha256-BJszHP+ZQX5IywWITAIh8LolnOhoXkMGBBzfaB3rTbk=",
      "url": "_framework/System.ObjectModel.of17k5hfvd.wasm"
    },
    {
      "hash": "sha256-CZmL0cxNpUjz1Y8D5tgoqyg3pLLThdvaNQWAFS2YM8g=",
      "url": "_framework/System.Private.CoreLib.z5i4mbxpnb.wasm"
    },
    {
      "hash": "sha256-gTwhUwtbtgoG/GnMdxjXqmPaKHXWlKo4ZguR/PAU9bM=",
      "url": "_framework/System.Private.Uri.hs4pogchng.wasm"
    },
    {
      "hash": "sha256-c9M/yqoCXj63whjdBb1wpN9BZkCmwyMtGVvwO+zaIQM=",
      "url": "_framework/System.Private.Xml.Linq.x7ng346m1a.wasm"
    },
    {
      "hash": "sha256-ceEDt4tNKMOClpK75nHv4UU/7Q5fA+mtsExF1MT7T8o=",
      "url": "_framework/System.Private.Xml.rhtpdwlvut.wasm"
    },
    {
      "hash": "sha256-4HwE8h6y12X5aTHRxgDAa4EatyRzPz8fAHgbzBW2Q/c=",
      "url": "_framework/System.Reactive.8yt6msyf3k.wasm"
    },
    {
      "hash": "sha256-28LLk/yw1oWfa8IDh4aqYeWxvQs4HWWFscua1rmCEsI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.h5m8f3k671.wasm"
    },
    {
      "hash": "sha256-jInTKCLV9uhZFZtM8nhAQXv10M5o9PpJO+I7GS40j2c=",
      "url": "_framework/System.Reflection.Emit.Lightweight.4mngibteh2.wasm"
    },
    {
      "hash": "sha256-5xC6Wp31dYBKSHnmvb7Jb37NP8Y9rELxQvkaPbCwFvw=",
      "url": "_framework/System.Reflection.Primitives.bjj4tmk12m.wasm"
    },
    {
      "hash": "sha256-krYk4OClLTGYToaMRQWFKxG7Y6GfR8ZSzmMKPlk5GK0=",
      "url": "_framework/System.Runtime.InteropServices.2bqtvcvkka.wasm"
    },
    {
      "hash": "sha256-Cjdb0G7x7YHp1aN8K34JIjyB6iQIEsmMfoZJJ71ZuOw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.mwa725m7o8.wasm"
    },
    {
      "hash": "sha256-2+iXIho7ASqFfJjqOQpMZa829lmiZO2xf5Wiucs7JyY=",
      "url": "_framework/System.Runtime.Numerics.pjmwp9ytr2.wasm"
    },
    {
      "hash": "sha256-6E4sgTnq6ro8WhDR9mvcA9G7DjBOI3iQ+jsjhxHVR+I=",
      "url": "_framework/System.Runtime.Serialization.Formatters.ogt7q5zc99.wasm"
    },
    {
      "hash": "sha256-Xr/0VnUFILIgj8CY7XHBugnyhaMFjWev30f+b0u2cZ0=",
      "url": "_framework/System.Runtime.Serialization.Primitives.al6s7etm22.wasm"
    },
    {
      "hash": "sha256-uuqbLqDcPGnwLA/ByBIqByti5Icbb2n1lvWlPdjYmxE=",
      "url": "_framework/System.Runtime.ei3maw12g5.wasm"
    },
    {
      "hash": "sha256-Q5AWDTyBw41bbdSP2KJ0pO0wO28goK4CGmdMMzWmxck=",
      "url": "_framework/System.Security.Cryptography.jgr9135b2f.wasm"
    },
    {
      "hash": "sha256-LlYX5HbDxa+g3PHrtMO6lABCowoJ7BnxHoFp2MZ+tm4=",
      "url": "_framework/System.Text.Encoding.Extensions.u9vy7ox4r6.wasm"
    },
    {
      "hash": "sha256-KqqWRjKnEB6AfDVf3rm0/MCd7SXbSGKyKpcY/+zEjSA=",
      "url": "_framework/System.Text.Encodings.Web.6kgc70ln9c.wasm"
    },
    {
      "hash": "sha256-IG/cbbz/t0LLZpY/y8zeSoLa1rI98Rl+6bQsWdcsEuY=",
      "url": "_framework/System.Text.Json.woy5mngb1q.wasm"
    },
    {
      "hash": "sha256-e/icD/C6G+wczr3LMHVVY4HXub/l+ewgYZhA7VHevHQ=",
      "url": "_framework/System.Text.RegularExpressions.zy5d5p3xi9.wasm"
    },
    {
      "hash": "sha256-zfnbWSRnKM/smYtYsPUOa2O58jaGN8N1+XgoTV8WT7o=",
      "url": "_framework/System.Threading.30jg6fucg0.wasm"
    },
    {
      "hash": "sha256-INEmRjos+NfW9DfekKIeVWXkvx4Zgk9ZxYhdZdr+zmY=",
      "url": "_framework/System.Transactions.Local.g099p8sk6x.wasm"
    },
    {
      "hash": "sha256-R9FktnaduRAvMaZfcRZAXAs4UUQFRWQ+IzNgO/1vj8I=",
      "url": "_framework/System.Xml.Linq.no17d80mwx.wasm"
    },
    {
      "hash": "sha256-/cIdoCxloVimsMPxWanjHxNEtxyIx1/ShbBpwnTVHUs=",
      "url": "_framework/System.Xml.ReaderWriter.byflpsteka.wasm"
    },
    {
      "hash": "sha256-hmJG3URfrJa13okNkDgzAwFZN17rrWqw+vAQ5VJoRZ0=",
      "url": "_framework/System.Xml.XDocument.ier3sxb28o.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-yVBTJq1WhNTrVo4fyqHwPjPrlAP5buV72twoFpY6SRU=",
      "url": "_framework/Wizard101.Blazor.WebAssembly.rzbenl945s.wasm"
    },
    {
      "hash": "sha256-fGCbiM9AdgZ40eRs560lnKxVLCRinns+X08cG6Fh6Yg=",
      "url": "_framework/Wizard101.Library.0fi19thw74.wasm"
    },
    {
      "hash": "sha256-MN8lHCw+pR1UawYMmjxvNH0LqWOyoION9YGH+QjaJn0=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-CCYb9Ckhwa9SRJ+HsZ3pMQ34L7cSaEjGlOfDaxD1LgU=",
      "url": "_framework/dotnet.native.gug7ty1rht.js"
    },
    {
      "hash": "sha256-qQ7Bf1vdiS9FNN0B4EejGx1MjB/UjNO3qyAL8Yppjo0=",
      "url": "_framework/dotnet.native.l5mm9zqtxs.wasm"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Z1Z7fs9jjhENwOSXu77LtoiP6aBBlWhkiJpZJXUkpmI=",
      "url": "_framework/netstandard.7sv2psa4n2.wasm"
    },
    {
      "hash": "sha256-kQIV9+RxGNo4fn2IB+JEn6u+z6u3Pk9+1jthexV7M70=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-HrDVZitZMAE9cgWh0iIiCzrhEEA/lEIFCxMZtxIq2ps=",
      "url": "fonts/Wizard Fancy.ttf"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-hrhF+uD2+JqjAKSBtYLLOre6Jnw71AtdfrJ3kWJ1SnY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-/WYZQLmsmX2mEupA8wFOkt8vSqD5O9f7oUwvcBeZyU4=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-73JZ1gHKuu5PTiginsJy+nbi40Bb8KfF7utVbi2O/rA=",
      "url": "sitemap.xml"
    },
    {
      "hash": "sha256-OdEkj53XDzoYb0un5CpQz96SKM3vSTEmkoWW/s1THOo=",
      "url": "spellbook.png"
    }
  ]
};
